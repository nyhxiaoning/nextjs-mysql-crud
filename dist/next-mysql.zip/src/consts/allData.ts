let allData = {
  baseURL: "http://localhost:3000",
  baseURL2:  "https://tracking.pixelmug.com"
};

export default allData;